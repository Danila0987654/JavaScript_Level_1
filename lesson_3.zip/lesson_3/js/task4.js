"use strict";

for(var i = 1, pyramid = " "; i <= 30; i++){
				pyramid += "x";
				console.log(pyramid);
}