"use strict";

for(var number = 0; number <= 20; console.log(number++ + " ")){}